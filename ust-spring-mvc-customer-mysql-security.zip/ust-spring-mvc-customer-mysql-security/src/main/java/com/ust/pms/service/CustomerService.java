package com.ust.pms.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.pms.model.Customer;
import com.ust.pms.repository.CustomerRepository;

@Service
public class CustomerService {
	
	@Autowired
	CustomerRepository customerRepository;
	
	public void saveCustomer(Customer customer) {
		customerRepository.save(customer);
	}
	
	public List<Customer> getAllCustomer() {
		return (List<Customer>) customerRepository.findAll();
	}

	public Customer getCustomers(Integer id) {
		Optional<Customer> customer = customerRepository.findById(id);
		return customer.get(); // searching based on id from all data
	}
	
	public void deleteCustomer(Integer id) {
		customerRepository.deleteById(id);
	}
	
	public void updateCustomer(Customer customer) {
		customerRepository.save(customer);
	}
	
	/*
	 * public List<Customer> searchProductByName(String productName){ return
	 * customerRepository.findByProductName(productName); }
	 * 
	 * public List<Customer> findByPrice(int price){ return
	 * productRepository.findByPriceGreaterThan(price); }
	 * 
	 * public boolean isProductExists(int productId) { return
	 * productRepository.existsById(productId);
	 * 
	 * }
	 */
	
	
}
