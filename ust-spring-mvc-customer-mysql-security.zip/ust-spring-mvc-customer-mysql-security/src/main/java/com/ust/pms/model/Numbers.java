package com.ust.pms.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.Data;

@Data
@Entity
public class Numbers {
	@Id
	@GeneratedValue
	private int attemptId;
	private  int firstNumber;
	private  int secondNumber;
	private  int thirdNumber;
	private  int fouthNumber;
	private  int fivthNumber;
	private  int result;
	
}
