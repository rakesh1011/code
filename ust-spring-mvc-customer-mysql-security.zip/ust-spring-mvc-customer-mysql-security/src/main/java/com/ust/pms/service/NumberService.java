package com.ust.pms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.pms.model.Numbers;
import com.ust.pms.repository.NumbersRepository;

@Service
public class NumberService {
	
	@Autowired
	NumbersRepository numbertRepository;
	
	public void saveNumbers(Numbers numbers) {
		numbertRepository.save(numbers);
	}

}
