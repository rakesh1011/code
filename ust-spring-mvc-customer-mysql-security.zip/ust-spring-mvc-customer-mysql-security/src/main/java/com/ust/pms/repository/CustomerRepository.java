package com.ust.pms.repository;

import org.springframework.data.repository.CrudRepository;

import com.ust.pms.model.Customer;

public interface CustomerRepository extends CrudRepository<Customer, Integer>{
	
	//public List<Customer> findByProductName(String productName);
	//public List<Customer> findByPriceGreaterThan(int price);
	//public List<Customer> findByPriceLessThan(int price);
	//public List<Customer> findByPriceBetween(int lowerRange,int greaterRange);
	
}
