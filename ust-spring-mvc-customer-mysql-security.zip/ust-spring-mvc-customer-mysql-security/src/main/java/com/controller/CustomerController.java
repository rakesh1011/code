package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ust.pms.model.Numbers;
import com.ust.pms.model.Customer;
import com.ust.pms.repository.NumbersRepository;
import com.ust.pms.service.NumberService;
import com.ust.pms.service.CustomerService;

@Controller
public class CustomerController {

	@Autowired
	CustomerService customerService;


	@RequestMapping("/")
	public ModelAndView index() {
		String username = null;
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if(principal instanceof UserDetails) {
			username = ((UserDetails) principal).getUsername();
		}
		
		ModelAndView view = new ModelAndView();
		view.addObject("username",username);
		view.setViewName("index");
		return view;
	}


	@RequestMapping("/addCustomer")
	public ModelAndView addCustomer() {
		return new ModelAndView("addCustomer","command",new Customer());
	}

	@RequestMapping("/saveCustomer")
	public String saveCustomer(Customer customer) {
		customerService.saveCustomer(customer);
		return "success";
	}

	/*
	 * @RequestMapping("/searchProductByIdForm") public ModelAndView
	 * searchProductByIdForm() { return new
	 * ModelAndView("searchProductById","command",new Customer()); }
	 */
	/*
	 * @RequestMapping("/searchProductById") public ModelAndView
	 * searchProductById(Customer product) { ModelAndView modelAndView = new
	 * ModelAndView(); modelAndView.setViewName("searchProductById"); int pId =
	 * product.getProductId(); if(ProductService.isProductExists(pId)) { Customer
	 * productDetails = ProductService.getProducts(pId);
	 * modelAndView.addObject("command",productDetails); }else {
	 * modelAndView.addObject("command",new Customer());
	 * modelAndView.addObject("msg","Product with Product id:"+pId+"does not exist"
	 * ); } return modelAndView; }
	 */

	@RequestMapping("/viewAllCustomer")
	public ModelAndView viewAllCustomers() {
		List<Customer> customer = customerService.getAllCustomer();
		return new ModelAndView("viewAllcustomer","customers",customer);
	}

	@GetMapping("/login")
	public String login(Model model,String error,String logout) {
		if(error != null)
			model.addAttribute("errorMsg", "Your username or password are incorrect");
		if(logout != null)
			model.addAttribute("msg", "You have been successfully logged out");
		return "login";

	}

}
